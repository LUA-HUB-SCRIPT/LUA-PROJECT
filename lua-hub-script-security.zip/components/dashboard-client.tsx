"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { authClient } from "@/lib/auth-client"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { ScriptDialog } from "@/components/script-dialog"
import { deleteScript, rotateToken } from "@/app/actions/scripts"
import { toast } from "sonner"
import {
  Plus,
  MoreVertical,
  Copy,
  Check,
  Pencil,
  Trash2,
  RefreshCw,
  LogOut,
  FileCode,
} from "lucide-react"

type Script = {
  id: string
  name: string
  slug: string
  token: string
  sourceCode: string
  createdAt: Date
  updatedAt: Date
}

export function DashboardClient({
  user,
  scripts,
  baseUrl,
}: {
  user: { name: string; email: string }
  scripts: Script[]
  baseUrl: string
}) {
  const router = useRouter()
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editing, setEditing] = useState<Script | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<Script | null>(null)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const [isPending, startTransition] = useTransition()

  const loaderFor = (s: Script) =>
    `loadstring(game:HttpGet("${baseUrl}/raw/${s.slug}?key=${s.token}"))()`

  const copyLoader = async (s: Script) => {
    await navigator.clipboard.writeText(loaderFor(s))
    setCopiedId(s.id)
    toast.success("Loader copied to clipboard")
    setTimeout(() => setCopiedId(null), 1500)
  }

  const handleDelete = () => {
    if (!deleteTarget) return
    const target = deleteTarget
    startTransition(async () => {
      try {
        await deleteScript(target.id)
        toast.success("Script deleted")
        setDeleteTarget(null)
        router.refresh()
      } catch {
        toast.error("Failed to delete")
      }
    })
  }

  const handleRotate = (s: Script) => {
    startTransition(async () => {
      try {
        await rotateToken(s.id)
        toast.success("Token rotated — old loader URLs are now dead")
        router.refresh()
      } catch {
        toast.error("Failed to rotate token")
      }
    })
  }

  const handleSignOut = async () => {
    await authClient.signOut()
    router.push("/sign-in")
    router.refresh()
  }

  const openNew = () => {
    setEditing(null)
    setDialogOpen(true)
  }

  const openEdit = (s: Script) => {
    setEditing(s)
    setDialogOpen(true)
  }

  return (
    <div className="min-h-svh bg-background">
      <header className="flex items-center justify-between border-b border-border px-6 py-4">
        <div className="flex items-center gap-2">
          <div className="flex size-8 items-center justify-center rounded-md bg-primary text-primary-foreground font-mono font-bold">
            {"</>"}
          </div>
          <span className="font-mono text-lg font-semibold tracking-tight">LUA HUB</span>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="gap-2">
              <span className="hidden text-sm text-muted-foreground sm:inline">{user.email}</span>
              <div className="flex size-7 items-center justify-center rounded-full bg-secondary text-xs font-medium uppercase">
                {user.name?.[0] ?? user.email[0]}
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={handleSignOut} className="gap-2 text-destructive">
              <LogOut className="size-4" /> Sign out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </header>

      <main className="mx-auto max-w-4xl px-6 py-10">
        <div className="mb-8 flex items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Your scripts</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {scripts.length} {scripts.length === 1 ? "script" : "scripts"} hosted privately
            </p>
          </div>
          <Button onClick={openNew} className="gap-2">
            <Plus className="size-4" /> Upload script
          </Button>
        </div>

        {scripts.length === 0 ? (
          <Card className="flex flex-col items-center justify-center gap-3 border-dashed py-16 text-center">
            <div className="flex size-12 items-center justify-center rounded-full bg-secondary">
              <FileCode className="size-6 text-muted-foreground" />
            </div>
            <div>
              <p className="font-medium">No scripts yet</p>
              <p className="text-sm text-muted-foreground">
                Upload your first Lua script to get a private loader URL.
              </p>
            </div>
            <Button onClick={openNew} variant="outline" className="mt-2 gap-2 bg-transparent">
              <Plus className="size-4" /> Upload script
            </Button>
          </Card>
        ) : (
          <div className="flex flex-col gap-4">
            {scripts.map((s) => (
              <Card key={s.id} className="p-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h2 className="truncate font-medium text-foreground">{s.name}</h2>
                      <Badge variant="secondary" className="gap-1 text-xs">
                        <Check className="size-3 text-primary" /> Obfuscated
                      </Badge>
                    </div>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      Updated {new Date(s.updatedAt).toLocaleDateString()}
                    </p>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="size-8 shrink-0">
                        <MoreVertical className="size-4" />
                        <span className="sr-only">Actions</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => openEdit(s)} className="gap-2">
                        <Pencil className="size-4" /> Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleRotate(s)} className="gap-2">
                        <RefreshCw className="size-4" /> Rotate token
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        onClick={() => setDeleteTarget(s)}
                        className="gap-2 text-destructive"
                      >
                        <Trash2 className="size-4" /> Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="mt-4 flex items-center gap-2 rounded-md border border-border bg-secondary/50 p-2">
                  <code className="min-w-0 flex-1 truncate font-mono text-xs text-muted-foreground">
                    {loaderFor(s)}
                  </code>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-7 shrink-0"
                    onClick={() => copyLoader(s)}
                  >
                    {copiedId === s.id ? (
                      <Check className="size-4 text-primary" />
                    ) : (
                      <Copy className="size-4" />
                    )}
                    <span className="sr-only">Copy loader</span>
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </main>

      <ScriptDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        editing={editing ? { id: editing.id, name: editing.name, sourceCode: editing.sourceCode } : null}
      />

      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this script?</AlertDialogTitle>
            <AlertDialogDescription>
              {'"'}
              {deleteTarget?.name}
              {'"'} will be permanently deleted and its loader URL will stop working. This cannot be
              undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isPending}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault()
                handleDelete()
              }}
              disabled={isPending}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
