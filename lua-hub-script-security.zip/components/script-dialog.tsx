"use client"

import type React from "react"
import { useState, useTransition } from "react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { createScript, updateScript } from "@/app/actions/scripts"
import { toast } from "sonner"

type ScriptData = {
  id: string
  name: string
  sourceCode: string
}

export function ScriptDialog({
  open,
  onOpenChange,
  editing,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  editing?: ScriptData | null
}) {
  const [name, setName] = useState(editing?.name ?? "")
  const [sourceCode, setSourceCode] = useState(editing?.sourceCode ?? "")
  const [isPending, startTransition] = useTransition()

  const isEdit = !!editing

  // Reset when the dialog opens with different data.
  const [lastId, setLastId] = useState<string | null>(null)
  if (open && editing?.id !== lastId) {
    setLastId(editing?.id ?? null)
    setName(editing?.name ?? "")
    setSourceCode(editing?.sourceCode ?? "")
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const fd = new FormData()
    fd.set("name", name)
    fd.set("sourceCode", sourceCode)
    if (isEdit && editing) fd.set("id", editing.id)

    startTransition(async () => {
      try {
        if (isEdit) {
          await updateScript(fd)
          toast.success("Script updated and re-obfuscated")
        } else {
          await createScript(fd)
          toast.success("Script uploaded and obfuscated")
        }
        onOpenChange(false)
        setName("")
        setSourceCode("")
        setLastId(null)
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Something went wrong")
      }
    })
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>{isEdit ? "Edit script" : "Upload script"}</DialogTitle>
            <DialogDescription>
              Paste your raw Lua below. It will be automatically obfuscated before it is stored.
            </DialogDescription>
          </DialogHeader>

          <div className="flex flex-col gap-4 py-4">
            <div className="flex flex-col gap-2">
              <Label htmlFor="script-name">Script name</Label>
              <Input
                id="script-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="My Aimbot Script"
                required
              />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="script-code">Lua source</Label>
              <Textarea
                id="script-code"
                value={sourceCode}
                onChange={(e) => setSourceCode(e.target.value)}
                placeholder={'print("Hello from LUA HUB")'}
                required
                spellCheck={false}
                className="min-h-64 font-mono text-sm"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              className="bg-transparent"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isPending}>
              {isPending ? "Saving..." : isEdit ? "Save changes" : "Upload & obfuscate"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
