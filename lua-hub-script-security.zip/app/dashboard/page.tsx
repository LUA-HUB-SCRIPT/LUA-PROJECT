import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import { redirect } from "next/navigation"
import { getScripts } from "@/app/actions/scripts"
import { DashboardClient } from "@/components/dashboard-client"

export default async function DashboardPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/sign-in")

  const scripts = await getScripts()
  const baseUrl =
    process.env.BETTER_AUTH_URL ??
    (process.env.VERCEL_PROJECT_PRODUCTION_URL
      ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
      : process.env.VERCEL_URL
        ? `https://${process.env.VERCEL_URL}`
        : (process.env.V0_RUNTIME_URL ?? ""))

  return (
    <DashboardClient
      user={{ name: session.user.name, email: session.user.email }}
      scripts={scripts}
      baseUrl={baseUrl}
    />
  )
}
