"use server"

import { auth } from "@/lib/auth"
import { db } from "@/lib/db"
import { scripts } from "@/lib/db/schema"
import { obfuscateLua } from "@/lib/obfuscate"
import { and, desc, eq } from "drizzle-orm"
import { headers } from "next/headers"
import { revalidatePath } from "next/cache"
import { randomBytes } from "crypto"

async function getUserId() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) throw new Error("Unauthorized")
  return session.user.id
}

function makeId() {
  return randomBytes(12).toString("hex")
}

function makeSlug() {
  // URL-safe random slug.
  return randomBytes(8).toString("hex")
}

function makeToken() {
  return randomBytes(16).toString("hex")
}

export async function getScripts() {
  const userId = await getUserId()
  return db
    .select()
    .from(scripts)
    .where(eq(scripts.userId, userId))
    .orderBy(desc(scripts.createdAt))
}

export async function getScript(id: string) {
  const userId = await getUserId()
  const rows = await db
    .select()
    .from(scripts)
    .where(and(eq(scripts.id, id), eq(scripts.userId, userId)))
    .limit(1)
  return rows[0] ?? null
}

export async function createScript(formData: FormData) {
  const userId = await getUserId()
  const name = String(formData.get("name") ?? "").trim()
  const sourceCode = String(formData.get("sourceCode") ?? "")

  if (!name) throw new Error("Name is required")
  if (!sourceCode.trim()) throw new Error("Script content is required")

  const obfuscatedCode = obfuscateLua(sourceCode)

  await db.insert(scripts).values({
    id: makeId(),
    userId,
    name,
    slug: makeSlug(),
    token: makeToken(),
    sourceCode,
    obfuscatedCode,
  })

  revalidatePath("/dashboard")
}

export async function updateScript(formData: FormData) {
  const userId = await getUserId()
  const id = String(formData.get("id") ?? "")
  const name = String(formData.get("name") ?? "").trim()
  const sourceCode = String(formData.get("sourceCode") ?? "")

  if (!id) throw new Error("Missing id")
  if (!name) throw new Error("Name is required")
  if (!sourceCode.trim()) throw new Error("Script content is required")

  const obfuscatedCode = obfuscateLua(sourceCode)

  await db
    .update(scripts)
    .set({ name, sourceCode, obfuscatedCode, updatedAt: new Date() })
    .where(and(eq(scripts.id, id), eq(scripts.userId, userId)))

  revalidatePath("/dashboard")
}

export async function deleteScript(id: string) {
  const userId = await getUserId()
  await db.delete(scripts).where(and(eq(scripts.id, id), eq(scripts.userId, userId)))
  revalidatePath("/dashboard")
}

// Rotate the access token for a script (invalidates old loader URLs).
export async function rotateToken(id: string) {
  const userId = await getUserId()
  await db
    .update(scripts)
    .set({ token: makeToken(), updatedAt: new Date() })
    .where(and(eq(scripts.id, id), eq(scripts.userId, userId)))
  revalidatePath("/dashboard")
}
