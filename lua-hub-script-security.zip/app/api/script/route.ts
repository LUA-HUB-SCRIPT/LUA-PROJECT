import { type NextRequest, NextResponse } from "next/server"

// Sumber script asli lo (raw GitHub). Bisa di-override lewat env var.
const SCRIPT_SOURCE_URL =
  process.env.SCRIPT_SOURCE_URL ?? "https://lua-hub-script.github.io/LUA-HUB-RAW/main.lua"

// Token rahasia yang harus dikirim executor. WAJIB di-set di Environment Variables.
const ACCESS_TOKEN = process.env.ACCESS_TOKEN

// Balasan generik biar orang gak tau ini proxy script.
function deny() {
  return new NextResponse("-- not found\n", {
    status: 404,
    headers: { "content-type": "text/plain; charset=utf-8" },
  })
}

export async function GET(req: NextRequest) {
  const userAgent = req.headers.get("user-agent") ?? ""

  // 1) Filter User-Agent: executor Roblox selalu mengandung "Roblox".
  //    Browser biasa (Chrome/Firefox/Safari) tidak.
  const isRobloxExecutor = /roblox/i.test(userAgent)
  if (!isRobloxExecutor) {
    return deny()
  }

  // 2) Filter token rahasia. Bisa lewat query (?key=...) atau header x-access-token.
  if (!ACCESS_TOKEN) {
    // Kalau lo belum set token, tolak semua demi keamanan.
    return deny()
  }
  const key = req.nextUrl.searchParams.get("key") ?? req.headers.get("x-access-token") ?? ""
  if (key !== ACCESS_TOKEN) {
    return deny()
  }

  // 3) Lolos filter -> ambil script asli dari GitHub dan teruskan.
  try {
    const res = await fetch(SCRIPT_SOURCE_URL, { cache: "no-store" })
    if (!res.ok) {
      return deny()
    }
    const script = await res.text()
    return new NextResponse(script, {
      status: 200,
      headers: {
        "content-type": "text/plain; charset=utf-8",
        "cache-control": "no-store",
      },
    })
  } catch {
    return deny()
  }
}
