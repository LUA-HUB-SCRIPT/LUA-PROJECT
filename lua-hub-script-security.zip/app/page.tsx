import Link from "next/link"
import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import { redirect } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ShieldCheck, Lock, Zap } from "lucide-react"

export default async function HomePage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (session?.user) redirect("/dashboard")

  return (
    <main className="min-h-svh bg-background flex flex-col">
      <header className="flex items-center justify-between px-6 py-4 border-b border-border">
        <div className="flex items-center gap-2">
          <div className="flex size-8 items-center justify-center rounded-md bg-primary text-primary-foreground font-mono font-bold">
            {"</>"}
          </div>
          <span className="font-mono text-lg font-semibold tracking-tight">LUA HUB</span>
        </div>
        <div className="flex items-center gap-2">
          <Button asChild variant="ghost" size="sm">
            <Link href="/sign-in">Sign in</Link>
          </Button>
          <Button asChild size="sm">
            <Link href="/sign-up">Get started</Link>
          </Button>
        </div>
      </header>

      <section className="flex flex-1 flex-col items-center justify-center px-6 py-20 text-center">
        <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs text-muted-foreground">
          <span className="size-1.5 rounded-full bg-primary" />
          Private script hosting for executors
        </span>
        <h1 className="max-w-3xl text-balance text-4xl font-bold tracking-tight sm:text-6xl">
          Host your Lua scripts. <span className="text-primary">Nobody reads them.</span>
        </h1>
        <p className="mt-6 max-w-xl text-pretty text-lg text-muted-foreground leading-relaxed">
          Upload a script, it gets auto-obfuscated and stored privately. Each script gets a raw
          loader URL that only Roblox executors can fetch — open it in a browser and you get nothing.
        </p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <Button asChild size="lg">
            <Link href="/sign-up">Start hosting free</Link>
          </Button>
          <Button asChild size="lg" variant="outline" className="bg-transparent">
            <Link href="/sign-in">I already have an account</Link>
          </Button>
        </div>

        <div className="mt-16 grid w-full max-w-3xl gap-4 sm:grid-cols-3">
          <Feature icon={<Lock className="size-5" />} title="Auto-obfuscated">
            Every upload is minified, string-encoded, and wrapped so the source is unreadable.
          </Feature>
          <Feature icon={<ShieldCheck className="size-5" />} title="Executor-only">
            Requests are filtered by User-Agent plus a secret token per script.
          </Feature>
          <Feature icon={<Zap className="size-5" />} title="Instant loader">
            Copy a ready-to-paste loadstring URL and drop it straight into your executor.
          </Feature>
        </div>
      </section>
    </main>
  )
}

function Feature({
  icon,
  title,
  children,
}: {
  icon: React.ReactNode
  title: string
  children: React.ReactNode
}) {
  return (
    <div className="rounded-lg border border-border bg-card p-5 text-left">
      <div className="mb-3 flex size-9 items-center justify-center rounded-md bg-accent text-accent-foreground">
        {icon}
      </div>
      <h3 className="font-medium text-foreground">{title}</h3>
      <p className="mt-1 text-sm text-muted-foreground leading-relaxed">{children}</p>
    </div>
  )
}
