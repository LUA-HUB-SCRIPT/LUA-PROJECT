// Custom Lua obfuscator.
// This is NOT unbreakable protection (nothing in plain-text Lua is), but it
// makes the source very hard to read: strips comments, encodes every string
// literal into a byte-array with a runtime decoder, renames local variables,
// minifies whitespace, and wraps the payload in a layered loadstring.

// Lua reserved words that must never be renamed.
const RESERVED = new Set([
  "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
  "goto", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then",
  "true", "until", "while",
  // Common globals we should not touch.
  "print", "pairs", "ipairs", "tostring", "tonumber", "type", "select",
  "setmetatable", "getmetatable", "rawget", "rawset", "rawequal", "next",
  "pcall", "xpcall", "error", "assert", "string", "table", "math", "os",
  "coroutine", "io", "require", "loadstring", "load", "unpack", "game",
  "workspace", "wait", "spawn", "task", "Instance", "Vector3", "Vector2",
  "CFrame", "Color3", "UDim2", "UDim", "Enum", "_G", "shared", "self",
  "tick", "warn", "typeof", "getgenv", "getrawmetatable", "hookfunction",
  "newcstack", "syn", "request", "http", "hookmetamethod", "setreadonly",
])

function randName(): string {
  // Produce confusing names made of I/l/1/0 and underscores.
  const chars = "IlO0_"
  let out = "_"
  const len = 6 + Math.floor(Math.random() * 6)
  for (let i = 0; i < len; i++) {
    out += chars[Math.floor(Math.random() * chars.length)]
  }
  return out
}

// --- Tokenizer helpers ------------------------------------------------------

// Remove comments while preserving strings. Handles -- line comments and
// --[[ ]] / --[==[ ]==] block comments, plus long-bracket strings.
function stripComments(src: string): string {
  let out = ""
  let i = 0
  const n = src.length

  while (i < n) {
    const c = src[i]

    // Short string
    if (c === '"' || c === "'") {
      const quote = c
      out += c
      i++
      while (i < n) {
        const ch = src[i]
        out += ch
        if (ch === "\\") {
          out += src[i + 1] ?? ""
          i += 2
          continue
        }
        i++
        if (ch === quote) break
      }
      continue
    }

    // Long bracket string [[ ]] or [==[ ]==]
    if (c === "[") {
      const m = /^\[(=*)\[/.exec(src.slice(i))
      if (m) {
        const level = m[1].length
        const close = "]" + "=".repeat(level) + "]"
        const end = src.indexOf(close, i + m[0].length)
        const stop = end === -1 ? n : end + close.length
        out += src.slice(i, stop)
        i = stop
        continue
      }
    }

    // Comment
    if (c === "-" && src[i + 1] === "-") {
      // Block comment?
      const rest = src.slice(i + 2)
      const bm = /^\[(=*)\[/.exec(rest)
      if (bm) {
        const level = bm[1].length
        const close = "]" + "=".repeat(level) + "]"
        const end = src.indexOf(close, i + 2 + bm[0].length)
        i = end === -1 ? n : end + close.length
        continue
      }
      // Line comment
      let j = i + 2
      while (j < n && src[j] !== "\n") j++
      i = j
      continue
    }

    out += c
    i++
  }

  return out
}

// Encode all string literals into decoder calls.
function encodeStrings(src: string, decoderName: string): string {
  let out = ""
  let i = 0
  const n = src.length

  while (i < n) {
    const c = src[i]
    if (c === '"' || c === "'") {
      const quote = c
      i++
      let value = ""
      while (i < n) {
        const ch = src[i]
        if (ch === "\\") {
          const nx = src[i + 1] ?? ""
          // Basic escape resolution.
          const map: Record<string, string> = {
            n: "\n", t: "\t", r: "\r", "\\": "\\", '"': '"', "'": "'", "0": "\0",
          }
          value += map[nx] ?? nx
          i += 2
          continue
        }
        if (ch === quote) {
          i++
          break
        }
        value += ch
        i++
      }
      // Emit as byte array decode.
      const bytes = Array.from(value).map((ch2) => ch2.charCodeAt(0))
      out += `${decoderName}({${bytes.join(",")}})`
      continue
    }

    // Skip long strings untouched (rare; keep correctness).
    if (c === "[") {
      const m = /^\[(=*)\[/.exec(src.slice(i))
      if (m) {
        const level = m[1].length
        const close = "]" + "=".repeat(level) + "]"
        const end = src.indexOf(close, i + m[0].length)
        const stop = end === -1 ? n : end + close.length
        out += src.slice(i, stop)
        i = stop
        continue
      }
    }

    out += c
    i++
  }

  return out
}

// Rename local variables declared with `local NAME` and `local function NAME`.
function renameLocals(src: string): string {
  const mapping = new Map<string, string>()

  // Find local declarations: local a, b, c = ...  and  local function foo
  const declRe = /\blocal\s+(function\s+)?([A-Za-z_][\w]*(?:\s*,\s*[A-Za-z_][\w]*)*)/g
  let match: RegExpExecArray | null
  while ((match = declRe.exec(src)) !== null) {
    const names = match[2].split(",").map((s) => s.trim())
    for (const name of names) {
      if (!RESERVED.has(name) && !mapping.has(name)) {
        mapping.set(name, randName())
      }
    }
  }

  let out = src
  for (const [orig, next] of mapping) {
    // Replace whole-word occurrences, but not after a dot (field access) or colon.
    const re = new RegExp(`(?<![\\w.:])${orig}(?![\\w])`, "g")
    out = out.replace(re, next)
  }
  return out
}

// Collapse whitespace safely (line by line so we don't merge tokens wrongly).
function minify(src: string): string {
  return src
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line.length > 0)
    .join(" ")
    .replace(/\s+/g, " ")
}

function toByteArray(str: string): number[] {
  const arr: number[] = []
  for (let i = 0; i < str.length; i++) arr.push(str.charCodeAt(i))
  return arr
}

export function obfuscateLua(source: string): string {
  const decoderName = randName()

  // 1. Strip comments
  let code = stripComments(source)
  // 2. Encode strings
  code = encodeStrings(code, decoderName)
  // 3. Rename locals
  code = renameLocals(code)
  // 4. Minify
  code = minify(code)

  // 5. Prepend a string decoder that turns byte arrays back into strings.
  const decoder = `local ${decoderName}=function(t)local s="";for i=1,#t do s=s..string.char(t[i])end;return s end `
  const inner = decoder + code

  // 6. Wrap the whole thing in a layered loadstring with an encoded payload.
  const payloadBytes = toByteArray(inner)
  const loaderVar = randName()
  const dataVar = randName()

  const wrapped =
    `local ${dataVar}={${payloadBytes.join(",")}} ` +
    `local ${loaderVar}="" ` +
    `for _i=1,#${dataVar} do ${loaderVar}=${loaderVar}..string.char(${dataVar}[_i]) end ` +
    `return (loadstring or load)(${loaderVar})()`

  const header = "-- Obfuscated by LUA-HUB. Do not edit.\n"
  return header + wrapped
}
